
This directory, containing lwIP-1.4 include files needed for the glue over
ESP8266_NONOS_SDK, appeared here because lwIP-1.4 directory disappeared after
esp8266/Arduino release 2.7.4.

These files are extracted from esp8266/Arduino's tools/sdk/lwip/, version/tag 2.7.4.
They also reflect what is in ESP8266_NONOS_SDK branch release/2.2.x.
